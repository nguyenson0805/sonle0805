<?php
require "PHPExcel.php";
function importFileExceal($file)
{
	$objFile = PHPExcel_IOFactory::identify($file);
	$objData = PHPExcel_IOFactory::createReader($objFile);
	//Chỉ đọc dữ liệu
	$objData->setReadDataOnly(true);

	// Load dữ liệu sang dạng đối tượng
	$objPHPExcel = $objData->load($file);

	//Lấy ra số trang sử dụng phương thức getSheetCount();
	// Lấy Ra tên trang sử dụng getSheetNames();

	//Chọn trang cần truy xuất
	$sheet  = $objPHPExcel->setActiveSheetIndex(0);

	//Lấy ra số dòng cuối cùng
	$Totalrow = $sheet->getHighestRow();
	//Lấy ra tên cột cuối cùng
	$LastColumn = $sheet->getHighestColumn();

	//Chuyển đổi tên cột đó về vị trí thứ, VD: C là 3,D là 4
	$TotalCol = PHPExcel_Cell::columnIndexFromString($LastColumn);

	//Tạo mảng chứa dữ liệu
	$data = [];

	//Tiến hành lặp qua từng ô dữ liệu
	//----Lặp dòng, Vì dòng đầu là tiêu đề cột nên chúng ta sẽ lặp giá trị từ dòng 2
	for ($i = 1; $i <= $Totalrow; $i++) {
		//----Lặp cột
		for ($j = 0; $j < $TotalCol; $j++) {

			// Tiến hành lấy giá trị của từng ô đổ vào mảng
			$data[$i - 1][$j] = $sheet->getCellByColumnAndRow($j, $i)->getValue();
		}
	}
	//Hiển thị mảng dữ liệu
	$datanew = array();
	$key = $data[0];
	function dataKV($key, $value)
	{
		return array($key => $value);
	}
	foreach ($data as $value) {
		$dataKV = array_map('dataKV', $key, $value);
		$merged = call_user_func_array('array_merge', $dataKV);
		array_push($datanew, $merged);
	}
	return $datanew;
}
function exportFileExel($data)
{
	//Khởi tạo đối tượng
	$excel = new PHPExcel();
	//Chọn trang cần ghi (là số từ 0->n)
	$excel->setActiveSheetIndex(0);
	//Tạo tiêu đề cho trang. (có thể không cần)
	$excel->getActiveSheet()->setTitle('AllContact');

	//Xét chiều rộng cho từng, nếu muốn set height thì dùng setRowHeight()
	$excel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
	$excel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
	$excel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
	$excel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
	$excel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
	$excel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
	$excel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
	//Xét in đậm cho khoảng cột
	$excel->getActiveSheet()->getStyle('A1:G1')->getFont()->setBold(true);
	//Tạo tiêu đề cho từng cột
	//Vị trí có dạng như sau:
	/**
	 * |A1|B1|C1|..|n1|
	 * |A2|B2|C2|..|n1|
	 * |..|..|..|..|..|
	 * |An|Bn|Cn|..|nn|
	 */
	$excel->getActiveSheet()->setCellValue('A1', 'name');
	$excel->getActiveSheet()->setCellValue('B1', 'phone');
	$excel->getActiveSheet()->setCellValue('C1', 'email');
	$excel->getActiveSheet()->setCellValue('D1', 'work');
	$excel->getActiveSheet()->setCellValue('E1', 'address');
	$excel->getActiveSheet()->setCellValue('F1', 'note');
	$excel->getActiveSheet()->setCellValue('G1', 'image');
	// thực hiện thêm dữ liệu vào từng ô bằng vòng lặp
	// dòng bắt đầu = 2
	$numRow = 2;
	foreach ($data as $row) {
		$excel->getActiveSheet()->setCellValue('A' . $numRow, $row["name"]);
		$excel->getActiveSheet()->setCellValue('B' . $numRow, $row["phone"]);
		$excel->getActiveSheet()->setCellValue('C' . $numRow, $row["email"]);
		$excel->getActiveSheet()->setCellValue('D' . $numRow, $row["work"]);
		$excel->getActiveSheet()->setCellValue('E' . $numRow, $row["adresss"]);
		$excel->getActiveSheet()->setCellValue('F' . $numRow, $row["note"]);
		$numRow++;
	}
	// Khởi tạo đối tượng PHPExcel_IOFactory để thực hiện ghi file
	// ở đây mình lưu file dưới dạng excel2007 và cho người dùng download luôn
	header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Content-Type: application/force-download");
	header("Content-Type: application/octet-stream");
	header("Content-Type: application/download");;
	header("Content-Disposition: attachment;filename=file.xls");
	header("Content-Transfer-Encoding: binary ");
	$objWriter = new PHPExcel_Writer_Excel2007($excel); 
	$objWriter->setOffice2003Compatibility(true);
	ob_start();
	SaveViaTempFile($objWriter);
	$xlsData = ob_get_contents();
	ob_end_clean();
	return $response =  array(
		'op' => 'ok',
		'file' => "data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64," . base64_encode($xlsData)
	);

}
function SaveViaTempFile($objWriter){
    $filePath = get_temp_dir () . "/" . rand(0, getrandmax()) . rand(0, getrandmax()) . ".tmp";
    $objWriter->save($filePath);
    readfile($filePath);
    unlink($filePath);
}
?>