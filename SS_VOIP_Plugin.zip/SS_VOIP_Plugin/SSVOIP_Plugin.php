<?php
/**
*Plugin Name: SSVOIP Plugin
*Plugin URI: https://sum.services
*Description: Plugin được xây dụng bởi Sum services team
*Version: 1.0.0
*Author: JackSon
*Author URI: https://sum.services
*License: GPLv2 or later
*/
defined('ABSPATH') or die('Ban khong duoc truy cap thang vao file');
define('SSVOIP_PATH',plugin_dir_path(__FILE__));
define('SSVOIP_URL',plugin_dir_url(__FILE__));
define('SSVOIP_BASENAME',plugin_basename(__FILE__));
define('SSVOIP_VER','1.0');
if (file_exists(dirname(__FILE__).'/vendor/autoload.php')) {
	require_once dirname(__FILE__).'/vendor/autoload.php';
}
if (file_exists(dirname(__FILE__).'/Resource/ExcelContact.php')){
	require_once dirname(__FILE__).'/Resource/ExcelContact.php';
}
// Activate
function activateVoidPlugin () {
	Inc\Base\Activate::activate();
}
register_activation_hook( __FILE__, 'activateVoidPlugin');
//Deactivate
function deactivateVoidPlugin(){
	Inc\Base\Deactivate::deactivate();
}
register_activation_hook( __FILE__,'deactivateVoidPlugin');
if (class_exists('Inc\\Init')) {
     Inc\Init::register_services();
}
