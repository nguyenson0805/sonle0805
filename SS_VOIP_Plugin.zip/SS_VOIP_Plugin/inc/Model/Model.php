<?php
namespace Inc\Model;
class Model{
	public $table_name;
	protected $glob;
	public function __construct(){
		global $wpdb;
		$this->glob=$wpdb;
	}
	public function getListTable(){
		$sql="Select * FROM $this->table_name ORDER BY id DESC";
		return $data=$this->get_results($sql,'ARRAY_A');
	}
	public function setTable($table){
		$this->table_name=$this->glob->prefix.$table;
	}
	public function get_row($sql,$kieudulieu=OBJECT){
		return $this->glob->get_row($sql,$object);
	}
	public function get_col($sql,$column){
		return $this->glob->get_col($sql,$column);
	}
	public function get_results($sql,$kieudulieu=OBJECT){
		
		return $this->glob->get_results($sql,$kieudulieu);
	}
	public function insert($param=array()){
		$this->glob->insert($this->table_name,$param);
	}
	public function update($param=array(),$where=array()){
		$this->glob->update($this->table_name,$param,$where);
	}
	public function delete($where=array()){
		$this->glob->delete($this->table_name,$where);
	}
	public function deleteAllRow(){
		$this->glob->query("TRUNCATE TABLE $this->table_name");
	}
	public function findTable($feild,$value){
		$sql="Select * FROM $this->table_name WHERE {$feild}={$value}";
		return $data=$this->get_results($sql,'ARRAY_A');
	}
} 
?>