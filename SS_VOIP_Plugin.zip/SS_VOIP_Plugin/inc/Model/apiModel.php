<?php 
namespace Inc\Model;
use Inc\Model\Model;
class apiModel extends Model{
	public function checkLogin($paramApiData=array(),$paramApiDataLogin=array()){
		$this->setTable("dataSSVOIP");
		$sql="Select * FROM $this->table_name";
		$data=$this->get_results($sql,'ARRAY_A');
		if(count($data)<=1){
			if($data!=null){
				$this->loadLoginPage($paramApiDataLogin);
			}else{
				$this->checkApiKey($paramApiData);
			}
		}else{
			$this->deleteAllRow();	
		}
	}
	public function  UpdateAPI($paramApiData=array()){
		if($paramApiData!=null){
			$this->checkApiKey($paramApiData);
		}
		require_once SSVOIP_PATH."inc/Views/connectApiPage.php";
	}
	public function loadLoginPage($param=array()){
		if($param!=null){
			$_SESSION['login'] = $param;
		}
		else{
			if(isset($_SESSION['login'])){
				require_once SSVOIP_PATH."inc/Views/MainPage.php";
			}else{
				require_once SSVOIP_PATH."inc/Views/loginPage.php";
			}
		} 
	}
	public function checkApiKey($param=array()){
		if(isset($_SESSION['login'])){
			unset($_SESSION['login']);
		}
		if($param!=null){
			$this->deleteAllRow();
			$this->insert(array('api_key' =>$param['id'], 'api_link' =>$param['token']));
		}
		require_once SSVOIP_PATH."inc/Views/support.php";
	}
}
?>