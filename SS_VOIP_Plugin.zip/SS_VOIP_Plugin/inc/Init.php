<?php
namespace Inc;
class Init{

	public static function get_services () {
        return [
            Lib\SettingLink::class,
            Lib\RedictPage::class,
            Lib\ContactSetting::class,
            Base\Enqueue::class,
        ];
    }

    private static function instantiate ($class) {
        $services = new $class;
        return $services;
    }
    
    public static function register_services () {
        foreach (self::get_services() as $class) {
            $service = self::instantiate($class);
            if (method_exists($service,'register')) {
                $service->register();
            }
        }
    }
	
}
