<div class="wrap ssvoip">
	<h1></h1>
	<div id="setting-error-tgmpa" class="updated settings-error notice is-dismissible ss-alert"> 
		<p><strong><span style="display: block; margin: 0.5em 0.5em 0 0; clear: both;">Bạn chưa kết nối API key</span>
			<span style="display: block; margin: 0.5em 0.5em 0 0; clear: both;">Bạn chưa có API key: <em><a href="http://localhost/wpskeleton/wp-admin/plugin-install.php?tab=plugin-information&amp;plugin=contact-form-7&amp;TB_iframe=true&amp;width=640&amp;height=500" class="thickbox">Sum Service</a></em> để đăng ký</span>
		</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
		<div class="ssvoip-content">
			<form action="" id="form-connect-api" method="post">
				<h2>Connect API</h2>
				<div class="txtb">
					<input type="text" name="apiKey">
					<span data-placeholder="API KEY"></span>
				</div>
				<div class="txtb">
					<input type="text" name="UrlApiAccess">
					<span data-placeholder="URL API ACCESS"></span>
				</div>
				<input type="submit" class="logbtn" value="CHECK ACCESS">
				<div class="bottom-text">
					<a href="#">Register new account?</a>
				</div>
			</form>
		</div>
</div>
