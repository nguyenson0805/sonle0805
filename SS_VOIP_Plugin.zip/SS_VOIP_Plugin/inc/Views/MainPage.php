
<div class="wrap ssvoip">
	<h1></h1>
	<div id="setting-error-tgmpa" class="updated settings-error notice is-dismissible ss-alert"> 
		<p><strong><span style="display: block; margin: 0.5em 0.5em 0 0; clear: both;">Thiết lập lại API:</span>
			<span style="display: block; margin: 0.5em 0.5em 0 0; clear: both;"><a href="admin.php?page=ssvoip-settings" class="button-primary">Go back Setting Page</a></span>
		</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>
		<div class="ssvoip-content">
			<h1>MAIN SSVOIP</h1>
			<div class="main-ssvoip-content">
				<div class="iframe-mobile">
					<iframe allow="microphone; camera" allowfullscreen="true" align="center" src="http://171.244.3.249:8084/samples/mobile_example.html" name="mobile" id="mobile" class="frame_conatiner" scrolling="no" width="350" height="780" frameborder="0"></iframe>
				</div>
				<div class="history-call">
					<h3><span>
					Phonebook</span><span><input type="text" name="search" placeholder="Search..." id="id-pro"></span></h3>
					<a class="add-button-file" id="open-add"><img src="<?=SSVOIP_URL.'img/add-button.svg'?>"></a>
					<a class="add-button-file child" id="add-button"><img src="<?=SSVOIP_URL.'img/user-plus-solid.svg'?>"></a>
					<a class="add-button-file child" id="add-button-import"><img src="<?=SSVOIP_URL.'img/file-excel-solid.svg'?>"></a>
					<div class="call-day">
					</div>	
					<div class="advertisement">
						Quảng cáo ở đây
						<div>
						</div>
						
					</div>
				</div>
			</div>