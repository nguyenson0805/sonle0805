<div class="wrap ssvoip">
    <h1></h1>
    <div id="setting-error-tgmpa" class="updated settings-error notice is-dismissible ss-alert">
        <p><strong><span style="display: block; margin: 0.5em 0.5em 0 0; clear: both;">Thiết lập lại API:</span>
                <span style="display: block; margin: 0.5em 0.5em 0 0; clear: both;"><a href="admin.php?page=ssvoip-settings" class="button-primary">Go back Setting Page</a></span>
            </strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>
    </div>
    <div class="ssvoip-content">
        <h1>SUPPORT SSVOIP</h1>
        <div class="main-content">
            
        </div>
        <p class="button-support"><a href="admin.php?page=ssvoip-settings" class="swal2-confirm swal2-styled" aria-label="" style="display: inline-block; border-left-color: rgb(48, 133, 214); border-right-color: rgb(48, 133, 214);">Bỏ qua</a><a type="button" class="swal2-confirm swal2-styled" aria-label="" href="#" target="_blank" style="display: inline-block; border-left-color: rgb(48, 133, 214); border-right-color: rgb(48, 133, 214);background-color: rgb(221, 51, 51);">Đăng ký APi</a></p>
    </div>