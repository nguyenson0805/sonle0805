<div class="wrap ssvoip">
	<h1></h1>
    <div class="result-error"></div>
		<div class="ssvoip-content">
			<form action="" id="form-login" method="post">
				<h2>Login system SSVoIP</h2>
				<div class="txtb">
					<input type="email" name="emailLogin">
					<span data-placeholder="Email"></span>
				</div>
				<div class="txtb">
					<input type="password" name="passwordLogin">
					<span data-placeholder="Password"></span>
				</div>
				<input type="submit" class="logbtn" value="LOGIN">
				<div class="bottom-text">
					<div><a href="admin.php?page=ssvoip-settings"><img src="<?=SSVOIP_URL.'img\back.svg'?>">Go back Setting Page</a></div>
					<div><a href="#"><img src="#">Forgot password?</a></div>
				</div>
			</form>
		</div>
</div>