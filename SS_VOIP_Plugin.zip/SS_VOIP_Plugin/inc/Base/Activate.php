<?php
namespace Inc\Base;

class Activate {
	public static function activate(){
		self::activateApiKey();
		/*self::activeVer();*/
		self::activeData();
	}
	public static function activateApiKey(){
		global $wpdb;
		$table_name=$wpdb->prefix."dataSSVOIP";
		if($wpdb->get_var( "SHOW TABLES LIKE '{$table_name}'" )!=$table_name){
			$sql="CREATE TABLE `{$table_name}`  ( 
			`id` INT(10) NOT NULL AUTO_INCREMENT , 
			`api_key` VARCHAR(200) NOT NULL , 
			`api_link` VARCHAR(200) NOT NULL , 
			 PRIMARY KEY (`id`)) 
			ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci";
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($sql);
		}
	}
/*	public static function activeVer(){
         add_option('SSVOIP_VER', SSVOIP_VER,'yes');
	}*/
	public static function activeData(){
		global $wpdb;
		$table_kh_name=$wpdb->prefix."dataContactSSVOIP";
		if($wpdb->get_var( "SHOW TABLES LIKE '{$table_kh_name}'" )!=$table_kh_name){
			$sql="CREATE TABLE `{$table_kh_name}` ( 
			`id` INT(10) NOT NULL AUTO_INCREMENT , 
			`name` VARCHAR(50) NOT NULL , 
			`email` VARCHAR(50) NOT NULL , 
			`work` VARCHAR(50) NOT NULL ,
			`adresss` VARCHAR(200) NOT NULL , 
			`note` VARCHAR(500) NOT NULL , 
			`phone` INT(20) NOT NULL , 
			`image` VARCHAR(200) NOT NULL , PRIMARY KEY (`id`)) 
			ENGINE = InnoDB CHARSET=utf8mb4 COLLATE utf8mb4_unicode_ci";
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($sql);
		}
	}
}
?>