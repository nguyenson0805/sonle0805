<?php
namespace Inc\Base;
class Deactivate {
	public static function deactivate(){
			
		}
}
?>