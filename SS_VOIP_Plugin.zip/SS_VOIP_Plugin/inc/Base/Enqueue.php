<?php
namespace Inc\Base;
class Enqueue{
	public function register () {
		add_action('admin_enqueue_scripts',array($this,'enqueue'));
		add_action( 'admin_head', array($this,'cdn'));
		add_action('init', array($this,'startSession'));
		add_action('wp_logout', array($this,'endSession'));
		add_action('wp_login', array($this,'endSession'));	
	}
	public function enqueue () {

		wp_enqueue_style('ssvoipstyle', SSVOIP_URL.'/assets/ssvoipcss.css');
		wp_enqueue_script('ssvoipscript', SSVOIP_URL.'/assets/ssvoipscript.js',array('jquery'), '', true);
		wp_localize_script( 'ssvoipscript', 'myAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
		wp_localize_script( 'ssvoipscript', 'SSVoIPBase', array( 
			'url' => SSVOIP_URL,
			'maxsize'=> wp_max_upload_size()
		));

	}
	public function cdn(){
		echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>';	
		echo '<script
		src="https://code.jquery.com/jquery-3.4.1.js"
		integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
		crossorigin="anonymous"></script>';
	}
	public function startSession() {
		if(!session_id()) {

			session_start();
		}
	}
	public function endSession() {
		session_destroy ();
	}
}
?>