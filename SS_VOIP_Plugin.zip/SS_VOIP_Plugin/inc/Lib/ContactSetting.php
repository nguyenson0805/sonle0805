<?php

namespace Inc\Lib;

use Inc\Model\Model;

class ContactSetting extends Model
{
	public function register()
	{
		$this->setTable("dataContactSSVOIP");
		add_action('wp_ajax_getDataKH', array($this, 'listContact'));
		add_action("wp_ajax_nopriv_getDataKH", array($this, 'listContact'));
		add_action('wp_ajax_addDataContact', array($this, 'addContact'));
		add_action("wp_ajax_nopriv_addDataContact", array($this, 'addContact'));
		add_action('wp_ajax_editDataContact', array($this, 'addContact'));
		add_action("wp_ajax_nopriv_editDataContact", array($this, 'addContact'));
		add_action('wp_ajax_deleteDataKH', array($this, 'delContact'));
		add_action("wp_ajax_nopriv_deleteDataKH", array($this, 'delContact'));
		add_action('wp_ajax_importExcel', array($this, 'importExcel'));
		add_action("wp_ajax_nopriv_importExcel", array($this, 'importExcel'));
		add_action('wp_ajax_exportExcel', array($this, 'exportExcel'));
		add_action("wp_ajax_nopriv_exportExcel", array($this, 'exportExcel'));
	}
	public function exportExcel()
	{
		$file = $this->getListTable();
		$state = exportFileExel($file);
		wp_send_json_success(array('state' => $state));
	}
	public function importExcel()
	{
		if (isset($_FILES)&&isset($_SESSION['login'])) {
			$html = "";
			$file = $_FILES['file']['tmp_name'];
			$dataFile = importFileExceal($file);
			$dataKey = ["name", "phone", "email", "work", "address", "note", "image"];
			foreach ($dataFile[0] as $value) {
				if (in_array($value, $dataKey) == false) {
					$dataFile = null;
					$state = "Title " . $value . "illegal or location";
					wp_send_json_success(array('state' => $state));
				}
			}
			unset($dataFile[0]);
			foreach ($dataFile as $value) {
				$phone = trim($value['phone']);
				$emailaddress = trim($value['email']);
				if (!empty($this->findTable('phone', $phone))) {
					$html .= "<p><span>{$phone}</span> phone number already exists</p>";
				}
				if (!is_numeric($phone)) {
					$html .= "<p><span>{$phone}</span> phone number isn't number</p>";
				}
				$pattern = '/^(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){255,})(?!(?:(?:\\x22?\\x5C[\\x00-\\x7E]\\x22?)|(?:\\x22?[^\\x5C\\x22]\\x22?)){65,}@)(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22))(?:\\.(?:(?:[\\x21\\x23-\\x27\\x2A\\x2B\\x2D\\x2F-\\x39\\x3D\\x3F\\x5E-\\x7E]+)|(?:\\x22(?:[\\x01-\\x08\\x0B\\x0C\\x0E-\\x1F\\x21\\x23-\\x5B\\x5D-\\x7F]|(?:\\x5C[\\x00-\\x7F]))*\\x22)))*@(?:(?:(?!.*[^.]{64,})(?:(?:(?:xn--)?[a-z0-9]+(?:-+[a-z0-9]+)*\\.){1,126}){1,}(?:(?:[a-z][a-z0-9]*)|(?:(?:xn--)[a-z0-9]+))(?:-+[a-z0-9]+)*)|(?:\\[(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9][:\\]]){7,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,5})?)))|(?:(?:IPv6:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){5,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,3}:)?)))?(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))(?:\\.(?:(?:25[0-5])|(?:2[0-4][0-9])|(?:1[0-9]{2})|(?:[1-9]?[0-9]))){3}))\\]))$/iD';
				if (preg_match($pattern, $emailaddress) != 1) {
					$html .= "<p><span>{$phone}</span> email<span>{$email}</span> invalid</p>";
				}
			}
			if ($html != "") {
				wp_send_json_success(array('state' => $html));
			} else {
				foreach ($dataFile as $value) {
					$phone = trim($value['phone']);
					$name = trim($value['name']);
					$emailaddress = trim($value['email']);
					$work = trim($value['work']);
					$address = trim($value['address']);
					$note = trim($value['note']);
					$this->insert(array('name' => $name, 'phone' => $phone, 'email' => $emailaddress, 'work' => $work, 'adresss' => $address, 'note' => $note, 'image' => ""));
				}
				wp_send_json_success(array('state' => 'success'));
			}
		} else {
			wp_send_json_success(array('state' => 'error_phone'));
		}
	}
	public function uploadImage($file){
		$maxsize=wp_max_upload_size(); 
		if(isset($file['image']['name'])&&$file['image']['size']==NULL){
			wp_send_json_success(array('state' =>"Your wordpresss upload maxsize is".$maxsize));
		}else{
            $override = array('test_form' => false);
			$image_up = wp_handle_upload($file['image'], $override);
			return $image = $image_up['url'];
		}
	}
	public function addContact()
	{
		if (isset($_SESSION['login']) && isset($_POST)) {
			$image = "";
			$param = $_POST;
			if (isset($_FILES) && !empty($_FILES)) {
				$image=$this->uploadImage($_FILES);
			}
			if (isset($param['id'])) {
				$this->uploadContact($param, $image);
			} else {
				$this->insertContact($param, $image);
			}
		} else {
			wp_send_json_success(array('state' => 'error'));
		}
	}
	public function listContact()
	{
		if (isset($_SESSION['login'])) {
			$data = $this->getListTable();
			wp_send_json_success($data);
		} else {
			wp_send_json_success(array('state' => 'error'));
		}
	}
	public function delContact()
	{
		if (isset($_SESSION['login']) && isset($_POST) && $_POST['id'] != null) {

			$this->delete(array('id' => $_POST['id']['data']));
			wp_send_json_success(array('state' => 'success'));
		} else {
			wp_send_json_success(array('state' => 'error'));
		}
	}
	public function insertContact($param, $image = "")
	{
		if (empty($this->findTable('phone', $param['phone']))) {
			$this->insert(array('name' => $param['name'], 'phone' => $param['phone'], 'email' => $param['email'], 'work' => $param['work'], 'adresss' => $param['address'], 'note' => $param['note'], 'image' => $image));
			wp_send_json_success(array('state' => 'success'));
		} else {
			wp_send_json_success(array('state' => 'Phone number already exists'));
		}
	}
	public function uploadContact($param, $image)
	{
		if (isset($param['image'])) {
			$image = $param['image'];
		}
		$checkPhone = $this->findTable('phone', $param['phone']);
		if ((!empty($checkPhone) && $checkPhone[0]['id'] == $param['id']) || empty($checkPhone)) {
			$this->update(array('name' => $param['name'], 'phone' => $param['phone'], 'email' => $param['email'], 'work' => $param['work'], 'adresss' => $param['address'], 'note' => $param['note'], 'image' => $image), array('id' => $param['id']));
			wp_send_json_success(array('state' => 'success'));
		} else {
			wp_send_json_success(array('state' => 'Phone number already exists'));
		}
	}
}
?>