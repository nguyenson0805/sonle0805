<?php
namespace Inc\Lib;
use Inc\Model\apiModel;
class RedictPage extends apiModel{
	public $slug="ssvoip";
	public function register(){
		add_action( 'wp_ajax_getAPI', array($this,'connectApi' ));
		add_action( 'wp_ajax_getAPILogin', array($this,'connectApi' ));
		add_action( 'wp_ajax_getAPI', array($this,'updateApiKey'));
		add_action('admin_menu',array($this,'register_my_custom_menu_page'));
	}
	public function updateApiKey(){
		if(isset($_POST['apiData'])){
			$this->UpdateAPI($_POST['apiData']);
		}
	}
	public function register_my_custom_menu_page() {
		add_menu_page( 'SS VOIP', 'SS VOIP', 'manage_options',$this->slug,[$this,'connectApi'],
			'dashicons-smartphone',10);
		add_submenu_page( $this->slug, 'Settings', 'Settings API', 'manage_options',$this->slug.'-settings', [$this,'updateApi']);
		add_submenu_page( $this->slug, 'Support', 'Support VoIP', 'manage_options',$this->slug.'-support-voip', [$this,'supportPage']);
	}
	public function supportPage(){
		require_once SSVOIP_PATH."inc/Views/support.php";
	}
    //view connect Api page
	public function connectApi(){
		if(isset($_POST)){
			$param=array();
			isset($_POST['apiData'])?$apiData=$_POST['apiData']:$apiData=array();
			isset($_POST['apiDataLogin'])?$apiDataLogin=$_POST['apiDataLogin']:$apiDataLogin=array();
			$this->checkLogin($apiData,$apiDataLogin);
		}else{
			$this->checkLogin();
		}
	}
}
?>