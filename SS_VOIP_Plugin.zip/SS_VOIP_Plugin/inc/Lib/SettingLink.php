<?php 
namespace Inc\Lib;
class SettingLink {
    public function register () {
        add_filter( 'plugin_action_links_'.SSVOIP_BASENAME, array($this,'setting_link'));
    }

    public function setting_link ($links) {
        $setting_link = '<a href="admin.php?page=ssvoip-settings">Settings</a>';
        $links[] = $setting_link;
        return $links;
    }
}
?>