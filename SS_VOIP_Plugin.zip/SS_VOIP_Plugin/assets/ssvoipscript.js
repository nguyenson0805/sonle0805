$(".txtb input").on("focus", function () {
	$(this).addClass("focus");
});
$(".txtb input").on("blur", function () {
	if ($(this).val() == "")
		$(this).removeClass("focus");
});
$("#open-add").on("click", function () {
	if ($(".add-button-file.child").hasClass('active')) {
		$(".add-button-file.child").removeClass('active')
	} else {
		$(".add-button-file.child").addClass('active')
	}
});
$(document).ready(function () {
	//form connect api
	$('#form-connect-api').on("submit", function (a) {
		connect_api(a);
	});
	//form Login
	$('#form-login').on("submit", function (a) {
		form_login(a)
	});
	//load ajax main
	loadMain();
	importExel();

});
function validate_Email(sender_email) {
	var strongRegex = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
	if (strongRegex.test(sender_email)) {
		return true;
	}
	else {
		return false;
	}
}
//main
function loadMain() {
	var allcontact = "";
	if ($(".main-ssvoip-content").index() == 1) {
		var data = {
			'action': 'getDataKH'
		}
		jQuery.post(ajaxurl, data, function (response) {
			$.each(response.data, function (key, value) {
				var hinh;
				if (value["image"] != "") {
					style = "background-image: url('" + value['image'] + "');"
				} else {
					style = "background-image: url("+ SSVoIPBase.url +"/img/19.gif)"
				}
				$(".call-day").append('<div class="call">' +
					'<div class="img" style="' + style + '"></div>' +
					'<div class="his">' +
					'<p>' + value['name'] + '</p>' +
					'<p><span><b>Phone: </b>' + value['phone'] + '</span></p>' +
					'</div>' +
					'<div class="call-phone"><img id="call-phone" src="'+ SSVoIPBase.url +'/img/phone-solid.svg"/></div>'
				)
			})
			allcontact = response.data;
			$(".history-call .call").each(function (index, value) {
				$(this).on("click", function () {
					detailContact(allcontact[index]);
				})
			})
		});
		$('#id-pro').keyup(function () {
			$('.call-day').html('');
			var searchField = $('#id-pro').val();
			var expression = new RegExp(searchField, "i");
			$.each(allcontact, function (key, value) {
				if (value.name.search(expression) != -1 || value.phone.search(expression) != -1 || searchField == value.id) {
					var hinh;
					if (value["image"] != "") {
						style = "background-image: url('" + value['image'] + "');"
					} else {
						style = "background-image: url("+ SSVoIPBase.url +"/img/19.gif)"
					}
					$(".call-day").append('<div class="call">' +
						'<div class="img" style="' + style + '"></div>' +
						'<div class="his">' +
						'<p>' + value['name'] + '</p>' +
						'<p><span><b>Phone: </b>' + value['phone'] + '</span></p>' +
						'</div>' +
						'<div class="call-phone"><img id="call-phone" src="'+ SSVoIPBase.url +'/img/phone-solid.svg"/></div>'
					)

				}
			});
			$(".history-call .call").each(function (index, value) {
				$(this).on("click", function () {
					detailContact(allcontact[index]);
				})
			})
		});
	}
	$("#add-button").on("click", function () {
		Swal.fire({
			title: 'Add Contact',
			html: '<div class="add-contact">' +
				'<input type="file" name="file" id="add-contact-image" class="inputfile" />' +
				'<label for="add-contact-image"><div class="img-add-img"><img src="'+ SSVoIPBase.url +'/img/camera.svg"></div></label>' +
				'<span id="result-img"></span>' +
				'<input type="text" id="add-contact-name" class="swal2-input" placeholder="Enter name*"></input>' +
				'<input type="text" id="add-contact-phone" class="swal2-input" placeholder="Enter phone*"></input>' +
				'<input type="email" id="add-contact-email" class="swal2-input" placeholder="Enter email"></input>' +
				'<input type="text" id="add-contact-work" class="swal2-input" placeholder="Enter work"></input>' +
				'<input type="text" id="add-contact-address" class="swal2-input" placeholder="Enter address"></input>' +
				'<textarea id="add-contact-text" class="swal2-input" placeholder="Note here..."></textarea>' +
				'</div>',
			confirmButtonText: 'Add Contact',
			preConfirm: () => {
				let name = Swal.getPopup().querySelector('#add-contact-name')
				let phone = Swal.getPopup().querySelector('#add-contact-phone')
				let email = Swal.getPopup().querySelector('#add-contact-email')
				let work = Swal.getPopup().querySelector('#add-contact-work')
				let address = Swal.getPopup().querySelector('#add-contact-address')
				let note = Swal.getPopup().querySelector('#add-contact-text')
				let image = Swal.getPopup().querySelector('#add-contact-image').files[0]
				if (name.value === "" || phone.value === "") {
					Swal.showValidationMessage(`Name/Phone empty`)
					errorInput.error("#add-contact-phone");
					errorInput.error("#add-contact-name");
				}
				$.each(allcontact, function (key, value) {
					if (value.phone == phone.value) {
						 Swal.showValidationMessage(`Phone number already exists`)
						 errorInput.error("#add-contact-phone");
					 }
				 });
				 if (phone.value !="" && $.isNumeric(phone.value)==false) {
					Swal.showValidationMessage('Invalid Phone Number!')
					errorInput.error("#add-contact-phone");
				}
				if (email.value !="" && validate_Email(email.value) == false) {
					Swal.showValidationMessage('Invalid Email Address!')
					errorInput.error("#add-contact-email");
				}
				if(image != null && image.size>SSVoIPBase.maxsize){
					Swal.showValidationMessage('Max size upload your website '+SSVoIPBase.maxsize+'KB!')
				}
				if (image != null) {
					if (image.type == "image/gif" || image.type == "image/png" || image.type == "image/jpeg") {
				 		image = image;
				 	} else {
				 		Swal.showValidationMessage(image.type + ' type error.(.gif .png .jpg) ')
				 	}
				 } else {
			 	image = "";
				 }
				var fd = new FormData();
				fd.append("image", image);
				fd.append("name", name.value);
				fd.append("phone", phone.value);
				fd.append("email", email.value);
				fd.append("work", work.value);
				fd.append("address", address.value);
				fd.append("note", note.value);

				return {
					data: fd
				}

			}
		}).then((result) => {
			if (result.value) {
				apfaddpost("addDataContact", result.value.data);
			}
		})
		$("#add-contact-image").change(function () {
			$('.img-add-img').css("background-image", "url(" + URL.createObjectURL(Swal.getPopup().querySelector('#add-contact-image').files[0]) + ")")
		});
	});
}
function detailContact($param) {
	if ($param["image"] != "") {
		style = "background-image: url('" + $param['image'] + "');"
	} else {
		style = "background-image: url("+ SSVoIPBase.url +"/img/19.gif)"
	}
	Swal.fire({
		html: '<div class="add-contact edit detail">' +
			'<label for="add-contact-image"><div class="img-add-img" style="' + style + '"></div></label>' +
			'<span id="result-img"></span>' +
			'<p class="text-input"><span>Name:</span><input type="text" id="add-contact-name" class="swal2-input" value="' + $param['name'] + '" readonly></p>' +
			'<p class="text-input"><span>Phone:</span><input type="text" id="add-contact-phone" class="swal2-input" value="' + $param['phone'] + '" readonly></p>' +
			'<p class="text-input"><span>Email:</span><input type="email" id="add-contact-email" class="swal2-input" value="' + $param['email'] + '" readonly></p>' +
			'<p class="text-input"><span>Work:</span><input type="text" id="add-contact-work" class="swal2-input" value="' + $param['work'] + '" readonly></p>' +
			'<p class="text-input"><span>Address:</span><input type="text" id="add-contact-address" class="swal2-input" value="' + $param['adresss'] + '" readonly></p>' +
			'<textarea id="add-contact-text" class="swal2-input" readonly>' + $param['note'] + '</textarea>' +
			'<button type="button" class="swal2-confirm swal2-styled" id="bt-call" aria-label="" style="display: inline-block; border-left-color: rgb(48, 133, 214); border-right-color: rgb(48, 133, 214);">CALL</button><button type="button" class="swal2-confirm swal2-styled" id="bt-edit" aria-label="" style="display: inline-block; border-left-color: rgb(48, 133, 214); border-right-color: rgb(48, 133, 214);">EDIT</button><button type="button" id="bt-delete" class="swal2-confirm swal2-styled" aria-label="" style="display: inline-block; border-left-color: rgb(48, 133, 214); border-right-color: rgb(48, 133, 214);background-color: rgb(221, 51, 51);">DELETE</button>' +
			'</div>',
		showConfirmButton: false,
	})
	$('#bt-delete').on("click", function () {
		Swal.fire({
			title: 'Are you sure?',
			text: "delete " + $param['name'] + " from the contacts list",
			type: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, delete!',
			preConfirm: () => {
				return {
					data: $param['id']
				}
			}
		}).then((result) => {
			if (result.value) {
				var data = {
					'action': 'deleteDataKH',
					'id': result.value
				}
				jQuery.post(ajaxurl, data, function (response) {
					if (response.data.state == "success") {
						$(".call-day").html('');
						loadMain();
						Swal.fire(
							'Deleted!',
							'Your file has been deleted.',
							'success'
						)
					} else {
						mySwalAlert.error('Something went wrong!');
					}
				})

			}
		})
	})
	$('#bt-edit').on("click", function () {
		Swal.fire({
			html: '<div class="add-contact edit">' +
				'<input type="hidden" id="add-contact-id" value="' + $param['id'] + '"/>' +
				'<input type="file" name="file" id="add-contact-image" class="inputfile" />' +
				'<label for="add-contact-image"><div class="img-add-img" style="' + style + '"><img src="'+ SSVoIPBase.url +'/img/camera.svg"></div></label>' +
				'<span id="result-img"></span>' +
				'<p class="text-input"><span>Name:</span><input type="text" id="add-contact-name" class="swal2-input" value="' + $param['name'] + '"></p>' +
				'<p class="text-input"><span>Phone:</span><input type="text" id="add-contact-phone" class="swal2-input" value="' + $param['phone'] + '"></p>' +
				'<p class="text-input"><span>Email:</span><input type="text" id="add-contact-email" class="swal2-input" value="' + $param['email'] + '"></p>' +
				'<p class="text-input"><span>Work:</span><input type="text" id="add-contact-work" class="swal2-input" value="' + $param['work'] + '"></p>' +
				'<p class="text-input"><span>Address:</span><input type="text" id="add-contact-address" class="swal2-input" value="' + $param['adresss'] + '"></p>' +
				'<textarea id="add-contact-text" class="swal2-input">' + $param['note'] + '</textarea>' +
				'</div>',
			confirmButtonText: 'Save',
			preConfirm: () => {
				let id = Swal.getPopup().querySelector('#add-contact-id')
				let name = Swal.getPopup().querySelector('#add-contact-name')
				let phone = Swal.getPopup().querySelector('#add-contact-phone')
				let email = Swal.getPopup().querySelector('#add-contact-email')
				let work = Swal.getPopup().querySelector('#add-contact-work')
				let address = Swal.getPopup().querySelector('#add-contact-address')
				let note = Swal.getPopup().querySelector('#add-contact-text')
				let image = Swal.getPopup().querySelector('#add-contact-image').files[0]
				if (name.value === '' || phone.value === '') {
					Swal.showValidationMessage(`Name/Phone empty`)
					errorInput.error("#add-contact-name");
					errorInput.error("#add-contact-phone");
				}
				if (email.value!="" && validate_Email(email.value) == false) {
					Swal.showValidationMessage('Invalid Email Address!')
					errorInput.error("#add-contact-email")
				}
				if(image != null && image.size>SSVoIPBase.maxsize){
					Swal.showValidationMessage('Max size upload your website '+SSVoIPBase.maxsize+'KB!')
				}
				 if ($.isNumeric(phone.value)==false) {
					Swal.showValidationMessage('Invalid Phone Number!')
					errorInput.error("#add-contact-phone");
				}
				if (image != null) {
					if (image.type == "image/gif" || image.type == "image/png" || image.type == "image/jpeg") {
						image = image;
					} else {
						Swal.showValidationMessage(image.type + ' type error.(.gif .png .jpg) ')
					}
				} else {
					image = $param['image'];
				}
				var fd = new FormData();
				fd.append("id", id.value);
				fd.append("image", image);
				fd.append("name", name.value);
				fd.append("phone", phone.value);
				fd.append("email", email.value);
				fd.append("work", work.value);
				fd.append("address", address.value);
				fd.append("note", note.value);

				return {
					data: fd
				}

			}
		}).then((result) => {
			if (result.value) {
				apfaddpost("editDataContact", result.value.data);
			}
		})
		$("#add-contact-image").change(function () {
			$('.img-add-img').css("background-image", "url(" + URL.createObjectURL(Swal.getPopup().querySelector('#add-contact-image').files[0]) + ")")
		});
	})
}
function apfaddpost(action, result) {
	var fd = result;
	fd.append("action", action);
	mySwalAlert.loading('Processing, please wait...');
	//Append here your necessary data
	jQuery.ajax({
		type: 'POST',
		url: ajaxurl,
		data: fd,
		processData: false,
		contentType: false,

		success: function (data, textStatus, XMLHttpRequest) {
			if (data.data.state == "success") {
				$(".call-day").html('');
				loadMain();
				mySwalAlert.success('Your contact has been saved');
			} else {
				mySwalAlert.error(data.data.state);
			}

		},

		error: function (MLHttpRequest, textStatus, errorThrown) {
			alert(errorThrown);
		}

	});
}
function connect_api(a) {
	a.preventDefault();
	host = location.hostname;
	slug = location.search.split('?page=')[1];
	apikey = $('input[name="apiKey"]').val();
	UrlApiAccess = $('input[name="UrlApiAccess"]').val();
	$.post("https://reqres.in/api/register",
		{
			"email": "eve.holt@reqres.in",
			"password": "pistol"
		},
		function (data) {
			var data = {
				'action': 'getAPI',
				'apiData': {
					"id": apikey,
					"token": UrlApiAccess
				}
			}
			mySwalAlert.loading('Processing, please wait...');
			jQuery.post(ajaxurl, data, function (response) {
				setTimeout(function () {
					if (slug == "ssvoip-settings") {
						location.href = location.origin+'/wp-admin/admin.php?page=ssvoip';
					} else {
						location.reload();
					}

				}, 5000);
			});
		});
}
function form_login(a) {
	a.preventDefault();
	var status = true;
	host = location.hostname;
	$(".result-error").html("<p></p>");
	emailLogin = $('input[name="emailLogin"]').val();
	passwordLogin = $('input[name="passwordLogin"]').val();
	if ($.trim(emailLogin).length == 0 || $(passwordLogin) == "") {
		mySwalAlert.error("Enter full field!");
		status = false;
	}
	if (validate_Email(emailLogin) == false) {
		mySwalAlert.error('Invalid Email Address!');
		status = false;
	}
	if (passwordLogin.length < 6) {
		mySwalAlert.error('Password must be greater than 8 characters!');
		status = false;
	}
	if (status == true) {
		$.post("https://reqres.in/api/register",
			{
				"email": emailLogin,
				"password": passwordLogin
			},
			function (data) {
				if (data) {
					var data = {
						'action': 'getAPILogin',
						'apiDataLogin': data
					};
					mySwalAlert.loading("Processing, please wait...");
					jQuery.post(ajaxurl, data, function (response) {
						setTimeout(function () {
							location.reload();
						}, 5000);

					});
				} else {
					alert('error');
				}
			}).fail(function (response) {
				mySwalAlert.error("Email Address or Password is incorrect!");
			});
	}
}
function importExel() {
	$("#add-button-import").on("click", function () {
		Swal.fire({
			title: 'Import/Export Excel',
			html: '<div class="excel-button">' +
				'<button type="button" class="swal2-confirm swal2-styled" id="bt-import" aria-label="" style="display: inline-block; border-left-color: rgb(48, 133, 214); border-right-color: rgb(48, 133, 214);">Import</button><button type="button" id="bt-export" class="swal2-confirm swal2-styled" aria-label="" style="display: inline-block; border-left-color: rgb(48, 133, 214); border-right-color: rgb(48, 133, 214);background-color: rgb(221, 51, 51);">Export</button>' +
				'</div>',
			showConfirmButton: false,
		})
		$("#bt-import").on("click", function () {
			(async () => {

				const { value: file } = await Swal.fire({
					title: 'Select file',
					input: 'file',
					inputAttributes: {
						accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
						'aria-label': 'Upload your profile picture'
					}
				})
				if (file && file.type == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
					var fd = new FormData();
					fd.append("file", file);
					apfaddpost("importExcel", fd);
				} else {
					mySwalAlert.error('File error');
				}
			})()
		})
		$("#bt-export").on("click", function () {
			var data = {
				'action': 'exportExcel'
			}
			Swal.fire({
				title: 'Are you sure?',
				text: "Download list contact",
				showCancelButton: true,
				confirmButtonColor: '#3085d6',
				cancelButtonColor: '#d33',
				confirmButtonText: 'Yes, download it!',
				}).then(() => {
					mySwalAlert.loading('Downloading, please wait...')
					jQuery.post(ajaxurl, data, function (response) {
						var $a = $("<a>");
						$a.attr("href", response.data.state.file);
						$("body").append($a);
						$a.attr("download", "AllContact.xlsx");
						$a[0].click();
						$a.remove();
						mySwalAlert.success("Download file success")
					})
				})
		
		})
	})
}
var mySwalAlert = {
	success: function (text) {
		Swal.fire({
			type: 'success',
			title: text,
			showConfirmButton: false,
			timer: 2500
		})
	},
	error: function (html) {
		Swal.fire({
			type: 'error',
			title: 'Wrong...',
			html: html
		})
	},
	loading: function (text) {
		Swal.fire({
			imageUrl: SSVoIPBase.url+'/img/loading1.gif',
			imageHeight: 100,
			imageAlt: 'A tall image',
			footer: text,
			showCancelButton: false,
			showLoaderOnConfirm: true,
			showConfirmButton: false,
			allowOutsideClick: false
		})
	}
}
var errorInput={
	error:function(location){
        $(location).addClass("inputerror");
		$(location).on("focus", function () {
			$(this).removeClass("inputerror");
		});
	}
}
