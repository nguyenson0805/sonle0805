<?php 
if (!defined('WP_UNINSTALL_PLUGIN')) {
	die;
}

/**
 * Clear database data
 */


global $wpdb;
$table_name_API=$wpdb->prefix."dataSSVOIP";
$table_name_contact=$wpdb->prefix."dataContactSSVOIP";
$wpdb->query( "DROP TABLE IF EXISTS $table_name_API" );
$wpdb->query( "DROP TABLE IF EXISTS $table_name_contact" );
session_destroy();
delete_option("SSVOIP_VER");
?>